﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class VALUES
    {
        public static int TILE_W = 30;
        public static int TILE_H = 30;
        public static int TILE_SIZE = 32;
    }
}
