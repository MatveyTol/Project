﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    static class TextureExt
    {
        public static Rectangle GetArea (this Texture2D texture, int x, int y, int width = 64, int height = 64)
        {
            return new Rectangle(x * width, y * height, width, height);
        }
    }
}
