﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Snake
{
    class Assets
    {
        public static Texture2D snake;
        public static Rectangle[] heads = new Rectangle[9];
        public static Rectangle[] tails = new Rectangle[9];
        public static Rectangle[] corners = new Rectangle[16];
    }
}
