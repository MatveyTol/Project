﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Snake
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Main main;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
            graphics.PreferredBackBufferWidth = VALUES.TILE_W * VALUES.TILE_SIZE;
            graphics.PreferredBackBufferHeight = VALUES.TILE_H * VALUES.TILE_SIZE;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();
            main = new Main();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            Assets.snake = Content.Load<Texture2D>("snake");
            Assets.heads[1] = Assets.snake.GetArea(4, 1);
            Assets.heads[2] = Assets.snake.GetArea(3, 1);
            Assets.heads[4] = Assets.snake.GetArea(3, 0);
            Assets.heads[8] = Assets.snake.GetArea(4, 0);

            Assets.tails[1] = Assets.snake.GetArea(3, 2);
            Assets.tails[2] = Assets.snake.GetArea(4, 2);
            Assets.tails[4] = Assets.snake.GetArea(4, 3);
            Assets.tails[8] = Assets.snake.GetArea(3, 3);

            Assets.corners[6] = Assets.snake.GetArea(0,0);
            Assets.corners[10] = Assets.snake.GetArea(1,0);
            Assets.corners[12] = Assets.snake.GetArea(2,0);
            Assets.corners[3] = Assets.snake.GetArea(0,1);
            Assets.corners[5] = Assets.snake.GetArea(2,1);
            Assets.corners[9] = Assets.snake.GetArea(2,2);
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// game-specific content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();
            main.Update();
            // TODO: Add your update logic here
            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.Black);
            spriteBatch.Begin();
            main.Draw(spriteBatch);
            spriteBatch.End();
            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }
    }
}
